jQuery(document).ready(function () {

    //when enter product page
    $.ajax({
        cache: false,
        type: 'POST',
        data: {
            'item_id': $('#item_id').val(),
        },
        url: getAppURL('products/json_info'),
        dataType:'json',
        success: function (data) {
            // console.log(data)
            if (data['result']) {
                // console.log(data['data']);
                var product = [{    //  adding a product to a shopping cart.
                    'name': data['data'].description,
                    'id': data['data'].id,
                    'price': data['data'].price,
                    'brand': ' ',
                    'category': data['data'].category,
                    'variant': data['data'].color,
                }];

                // Measure a view of product details. This example assumes the detail view occurs on pageload,
                // and also tracks a standard pageview of the details page.
                dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
                dataLayer.push({
                    'ecommerce': {
                        'detail': {
                            'actionField': { 'list': 'Apparel Gallery' },    // 'detail' actions have an optional list property.
                            'products': product
                        }
                    }
                });
            }
        }
    });




    $('#add_to_cart').on('click', function (c) {
        // alert($('input[name="size"]:checked').val())
        // return false;
        var count = 0;
        if ($('#msg_qty').text() !== '') {
            count++;
        }
        if ($('#category').val() !== "Wallets") {
            if ($('#category').val() !== "Hats") {
                if ($('input[name="size"]:checked').val() == undefined) {
                    $('#msg_size').html(_lang.Required).css('color', 'red');
                    count++;
                } else {
                    $('#msg_size').html('');
                }
            }
        }
        if (count == 0) {
            console.log($('#item_id').val());
            $.ajax({
                cache: false,
                type: 'POST',
                data: {
                    'item_id': $('#item_id').val(),
                    'qty': $('#qty_value').val(),
                    'size': $('input[name="size"]:checked').val(),
                },
                url: getAppURL('cart/add_to_cart'),
                success: function (data) {
                    console.log(data)
                    if (data['res'] == 'ok') {
                        $('#cartCountNav').text(data['count_cart']);
                        $('#cartCountNavPhone').text(data['count_cart']);
                        $('#modal_text').text(_lang.Product_added_successfuly_to_Cart);
                        $('#modal_image').attr("src", "assets/images/add_to_cart.png");
                        $('#modal_image').width(50);
                        $('#modal_image').height(50);
                        $('#go_wishlist').hide();
                        //fire data layer add to cart
                        fireAddToCart($('#item_id').val(), $('#qty_value').val());
                        //fire data layer add to cart end
                        $('#product_modal').modal('show');
                    }
                }
            });
        }
    });

    //buy_now_btn action start 
    // this button is add product to cart then redirect to checkout page
    $('#buy_now_btn').on('click', function (c) {
        // alert($('input[name="size"]:checked').val())
        // return false;
        var count = 0;
        if ($('#msg_qty').text() !== '') {
            count++;
        }
        if ($('#category').val() !== "Wallets") {
            if ($('#category').val() !== "Hats") {
                if ($('input[name="size"]:checked').val() == undefined) {
                    $('#msg_size').html(_lang.Required).css('color', 'red');
                    count++;
                } else {
                    $('#msg_size').html('');
                }
            }
        }
        if (count == 0) {
            $.ajax({
                cache: false,
                type: 'POST',
                data: {
                    'item_id': $('#item_id').val(),
                    'qty': $('#qty_value').val(),
                    'size': $('input[name="size"]:checked').val(),
                },
                url: getAppURL('cart/add_to_cart'),
                success: function (data) {
                    console.log(data)
                    if (data['res'] == 'ok') {
                        // $('#cartCountNav').text(data['count_cart']);
                        // $('#cartCountNavPhone').text(data['count_cart']);
                        // $('#modal_text').text(_lang.Product_added_successfuly_to_Cart);
                        // $('#modal_image').attr("src", "assets/images/add_to_cart.png");
                        // $('#modal_image').width(50);
                        // $('#modal_image').height(50);
                        // $('#go_wishlist').hide();
                        // $('#product_modal').modal('show');
                        window.location.href = getAppURL('Checkout/direct_order');
                    }
                }
            });
        }
    });
    //buy_now_btn end

    $('#wishlist').on('click', function (e) {
        // alert($('#item_id').val())
        // return false;
        $.ajax({
            cache: false,
            type: 'POST',
            data: {
                'item_id': $('#item_id').val(),
            },
            url: getAppURL('users/add_item_to_customer_wishlist'),
            success: function (data) {
                console.log($('#item_id').val(), data)
                if (data !== "0") {
                    $('#go_wishlist').show();
                    $('#modal_image').attr("src", "assets/images/wishlist.png");
                    if (data === "1") {
                        $('#modal_text').text(_lang.Product_added_successfuly_to_Wishlist);
                        $.ajax({
                            cache: false,
                            type: 'POST',
                            url: getAppURL('accounts/get_user_wishlist_count'),
                            success: function (data) {
                                $('#WishlistCountNavPhone').text(data);
                                $('#WishlistCountNav').text(data);
                            }
                        });
                    }
                    if (data === "2") {
                        $('#modal_text').text(_lang.Product_already_exists_in_Wishlist);
                    }
                    $('#product_modal').modal('show');
                } else {
                    $('#modal_image').attr("src", "assets/images/warning.png");
                    $('#modal_text').text(_lang.sorry_you_must_be_logged_in_to_add_to_wishlist);
                    $('#go_wishlist').hide();
                    $('#product_modal').modal('show');
                }
            }
        });
    });
    $('#go_wishlist').on('click', function (e) {
        window.location.href = getAppURL('accounts/wishlist');
    });
});


//fire data layer add to cart function
function fireAddToCart(item_id, qty) {
    $.ajax({
        cache: false,
        type: 'POST',
        data: {
            'item_id': $('#item_id').val(),
        },
        url: getAppURL('products/json_info'),
        dataType:'json',
        success: function (data) {
            // console.log(data)
            if (data['result']) {
                // console.log(data['data']);
                var product = [{    //  adding a product to a shopping cart.
                    'name': data['data'].description,
                    'id': data['data'].id,
                    'price': data['data'].price,
                    'brand': ' ',
                    'category': data['data'].category,
                    'variant': data['data'].color,
                    'quantity': qty
                }];
                
                // Measure adding a product to a shopping cart by using an 'add' actionFieldObject
                // and a list of productFieldObjects.
                window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
                window.dataLayer.push({
                    'event': 'addToCart',
                    'ecommerce': {
                        'currencyCode': 'USD',
                        'add': {                                // 'add' actionFieldObject measures.
                            'products': product
                        }
                    }
                });
                
            }
        }
    });
}

function fireWhatsAppClick(){

}