jQuery(document).ready(function () {
    $('#coupons_table').DataTable( {
        "pagingType": "full_numbers"
    } );
});