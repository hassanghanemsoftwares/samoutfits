<br><br><br><br>
<div id="page-wrapper">
    <div class="main-page">
        <div class="tables">
            <h3 class="title1"><?php echo  $this->lang->line('Questions') ?> <i class="fa fa-question"></i></h3>    
            
            <div class="inbox-page">
	<div class="search-box">
					<form class="input">
						<input class="sb-search-input input__field--madoka" placeholder="Search..." type="search" id="input-31" />
						<label class="input__label" for="input-31">
							<svg class="graphic" width="100%" height="100%" viewBox="0 0 404 77" preserveAspectRatio="none">
								<path d="m0,0l404,0l0,77l-404,0l0,-77z"/>
							</svg>
						</label>
					</form>
				</div>
     <br><br>  <br><br>
        	<div class="inbox-row widget-shadow" id="accordion" role="tablist" aria-multiselectable="true">

					
						<div class="mail mail-name">
						     <h6># Q: <span style="color:red;font-weight:bold"> 1 </span></h6>
						
						</div>	<div class="mail">   <h6>Question .... </h6></div>
						<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
							<div class="mail-right"><p>View Answer  <i class="fa fa-caret-down" aria-hidden="true"></i></p></div>
						</a>
				
					
						<div class="clearfix"> </div>
						<div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
							
							<div class="mail-body">
							    
								<p>Answer ... </p>
							
							
							</div>
							
					</div>
			</div>
			<br>
               	<div class="inbox-row widget-shadow" id="accordion" role="tablist" aria-multiselectable="true">

					
						<div class="mail mail-name">
						     <h6># Q: <span style="color:red;font-weight:bold"> 2 </span></h6>
						
						</div>	<div class="mail">   <h6>Question .... </h6></div>
						<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse2" aria-expanded="true" aria-controls="collapseOne">
							<div class="mail-right"><p>View Answer  <i class="fa fa-caret-down" aria-hidden="true"></i></p></div>
						</a>
				
					
						<div class="clearfix"> </div>
						<div id="collapse2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
							
							<div class="mail-body">
							    
								<p>Answer ... </p>
							
							
							</div>
							
					</div>
			</div> 
            </div>





        </div>
    </div>
</div>
</div>