<?php
$lang['home'] = 'Home';
