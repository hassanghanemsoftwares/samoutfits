<center>
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <img src="<?php echo base_url(); ?>assets/images/welcome_home.webp" width="60%" height="auto" alt="">
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h3>You Are Welcome In <span style="color:#ffdf59 !important;">Samoutfits Admin Panel</span></h3>
            </div>
        </div>
    </div>
</center>
<script>
    function back() {
        window.history.back();
    }
</script>