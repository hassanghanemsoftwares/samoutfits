<center>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h3>You Do Not Have Permission To Access This Page</h3>
            </div>
        </div>
        <div class="row text-center">
            <div class="col-md-12">
                <p id="listbtn">
                    <a id="bgback" accesskey="b" class="btn btn-primary" onclick="back()">Back</a>
                </p>
            </div>
        </div>
    </div>
</center>
<script>
    function back() {
        window.history.back();
    }
</script>