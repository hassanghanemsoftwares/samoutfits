
jQuery(document).ready(function ($) {
	inputToDatepickerA($('#start_date, #end_date', '#fiscalYearForm'));
});