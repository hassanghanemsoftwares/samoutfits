jQuery(document).ready(function () {
    window.warehousesDT = null;
    let dtActionsHTML =
        '<button type="button" class="btn bt-link btn-xs i-adjust" style="background-color: #333;" onclick="openAdjustModal(%d, \'%s\', \'%n\', \'%q\', \'%b\', \'%x\')">' +
        '<i class="glyphicon glyphicon-adjust text-yellow" title="Adjust"></i>' +
        '</button>';
    /***************************************************/
    var $dtTbl = $('#warehousesTbl');
    BuildDataTableColumnSearch($dtTbl, 'warehousesDT');
    EnhanceDataTableSearch(window.warehousesDT = $dtTbl.DataTable({
        orderCellsTop: true, fixedHeader: { headerOffset: 0 }, searchDelay: _GST, lengthMenu: _dtLengthMenu,
        serverSide: true, processing: true, scrollX: false, deferLoading: $dtTbl.attr('data-num-rows'),
        order: [[0, 'asc']], ajax: { url: getAppURL('warehouses/inventory'), type: 'GET', searchDelay: _GST },
        columns: [{ data: 'barcode' }, { data: 'description' }, { data: 'size' }, { data: 'warehouse' }, { data: 'shelf' }, { data: 'total_qty' }, { data: 'price_ttc' }, { data: 'item_id' }],
        columnDefs: [
            {
                targets: 7, orderable: false, createdCell: (td, itemId, row) => {
                    $(td).addClass('text-right').html(dtActionsHTML.replace(/%d/g, parseInt(itemId))
                        .replace(/%s/g, row.warehouse)
                        .replace(/%n/g, row.shelf)
                        .replace(/%b/g, row.barcode)
                        .replace(/%x/g, row.size)
                        .replace(/%q/g, row.total_qty)
                        );
                }
            }
        ],
        stateSave: true,
		stateSaveCallback: function (settings, data) {
			localStorage.setItem('DataTables_' + settings.sInstance, JSON.stringify(data))
		},
		stateLoadCallback: function (settings) {
			return JSON.parse(localStorage.getItem('DataTables_' + settings.sInstance))
		},
		"stateSaveParams": function (settings, data) {
			var temp = {};
			$('#warehousesTbl thead').find("tr:eq(1)").find('input').each(function (n) {
				temp[$(this).attr('placeholder')] = document.getElementById($(this).attr('id')).value;
			});		
			data.colsFilter = temp;
			console.log(temp);
		},
		"stateLoadParams": function (settings, data) {
			$.each(data.colsFilter, function (key, val) {
				$('#warehousesTbl thead input[placeholder="' + key + '"]').val(val);
			});
		},
		"stateLoaded": function (settings, data) {
			$dtTbl.DataTable().ajax.reload();
		}
    }), 2048);

    $('#reset_filters').on('click', function (e) {
		$('#warehousesTbl thead').find("tr:eq(1)").find('input').each(function (n) {
			document.getElementById($(this).attr('id')).value = "";
		});
		var table = $('#warehousesTbl').DataTable();
		table
			.search('')
			.columns().search('')
			.draw();
	});
});

function openAdjustModal(item_id, warehouse, shelf, qty, barcode, size) {
    // if ($('#user_type').val() !== "Employee") {
        $('#adjust_product_data').text(barcode.concat(' - ').concat(size).concat(' - ').concat(warehouse).concat(' - ').concat(shelf));
        $('#old_qty').val(qty);
        $('#adjust_item_id').val(item_id);
        $('#adjust_size').val(size);
        $('#adjust_warehouse').val(warehouse);
        $('#adjust_shelf').val(shelf);
        $('#new_qty').val(0);
        $('#itemAdjustModalForm').modal('show');
    // }
}