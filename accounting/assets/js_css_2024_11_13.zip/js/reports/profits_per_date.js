jQuery(document).ready(function ($) {
    inputToDatepickerA($('#from_date, #to_date'));
});